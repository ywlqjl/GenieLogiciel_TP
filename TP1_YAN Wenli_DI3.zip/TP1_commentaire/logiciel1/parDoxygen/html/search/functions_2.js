var searchData=
[
  ['main',['main',['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.c']]],
  ['matricediff',['matriceDiff',['../main_8c.html#a00db591ab5b67601a6608be5d93067d3',1,'main.c']]],
  ['max',['max',['../main_8c.html#af082905f7eac6d03e92015146bbc1925',1,'main.c']]],
  ['min',['min',['../main_8c.html#abd8bbcfabb3ddef2ccaafb9928a37b95',1,'main.c']]],
  ['mvm',['MVM',['../main_8c.html#ad8a6cdc77372408327a94bb73763a33b',1,'main.c']]]
];
